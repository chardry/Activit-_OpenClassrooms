import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  //Array Posts
  posts = [
    {
      title: 'Angular',
      content: 'Angular is a platform for building mobile and desktop web applications. Join the community of millions of developers who build compelling user interfaces.',
      loveIts: 1,
      created_at: new Date()
    },
    {
      title: 'Mon deuxième post',
      content: 'Angular is a platform for building mobile and desktop web applications. Join the community of millions of developers who build compelling user interfaces.',
      loveIts: -2,
      created_at: new Date()
    },
    {
      title: 'Autre post',
      content: 'Angular is a platform for building mobile and desktop web applications. Join the community of millions of developers who build compelling user interfaces.',
      loveIts: 1,
      created_at: new Date()
    }
  ]
}
